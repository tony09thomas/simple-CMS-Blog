<!DOCTYPE html>
<html>
<head>
	<title>About Us</title>
</head>
<body bgcolor="grey">
<center>
	<h1><b>Our Team</b></h1>
    <h3>Founder</h3>
    <dl>
      <dt><a target="_blank" href="https://www.linkedin.com/in/tony09thomas/">Tony Thomas</a></dt>
      <dd>
      	<br>
        <img src="images/tony.jpg" width="300" height="250" />
        <p>- Pursuing Masters in Cyber Security from National College of Ireland. <br>- Graduated with Bachelors degree in Computer Applications -</p>
      </dd>
  </dl>

</center>



</body>
</html>