<div id="header" style="background-color:black">

	<a href="index.php"><h1><font color="red" size="20">Ynot Blog</font></h1></a>
<!--<div id="logo"><img src="images/malala.jpg"></div>
<div id="banner"><img src="images/ad_banner.jpg"></div>-->
</div>