

<div id="navbar">
<ul>
	<li><a href="index.php">Home</a></li>
	<li><a href="register.php">SignUp</a></li>


	
		<!--<li><a href="login.php">Your Profile</a></li>-->
		
	
			<li><a href="login.php">Login</a></li>
	



	<!--<li><a href="login.php">Login</a></li>-->
	
	<li><a href="about.php">About Us</a></li>
	<li><a href="contact.php">Contact</a></li>

</ul>
</div>
