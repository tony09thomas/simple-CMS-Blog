<html>
	<head>
		<title>Ynot Blog</title>

<link rel="stylesheet" href="style.css" media="all">
	</head>

<body>
<div><?php include("includes/header.php"); ?></div>
<div><?php include("includes/navbar.php"); ?></div>
<div><?php include("includes/main_content.php"); ?></div>
<div><?php include("includes/sidebar.php"); ?></div>


<div id="footer"><b><br><br><center>© 2019 YNOT BLOG</center></b></div>




</body>
</html>