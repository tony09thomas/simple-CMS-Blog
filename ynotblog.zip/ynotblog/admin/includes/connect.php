<?php 
$con = mysqli_connect("localhost","root","WbY@ieQXpm96B#OPBUey","ynotblogdb");
if (!$con)
  {
  die('Could not connect: ' . mysqli_connect_error());
  }
?>